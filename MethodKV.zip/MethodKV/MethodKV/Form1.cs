﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZedGraph;
using System.IO;
using ExcelDataReader;

namespace MethodKV
{
    public partial class Form1 : Form
    {

        private string fileName = string.Empty;

        private DataTableCollection tableCollection = null;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void закрытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void расчитатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count == 0)
            {
                MessageBox.Show("Вы не ввели данные!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }else
            {

            }
        }

        private void очиститьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Очистить введённые данные?", "Очистка", MessageBoxButtons.YesNo);
            if(DialogResult == DialogResult.Yes)
            {
                GraphPane graphfield = zedGraphControl1.GraphPane;
                graphfield.CurveList.Clear();
                graphfield.CurveList.Clear();
                graphfield.GraphObjList.Clear();
                zedGraphControl1.AxisChange();
                zedGraphControl1.Invalidate();

                tb1.Clear();
                tb2.Clear();
            }
            else if (DialogResult == DialogResult.No)
            {

            }
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (toolStripComboBox2.SelectedIndex == 0)
            {
                if(numericUpDown1.Text == "0" )
                {
                    MessageBox.Show("Вы не ввели количество строк!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    int stroka;

                    stroka = Convert.ToInt32(numericUpDown1.Value);
                    

                    dataGridView1.RowCount = stroka;
                    dataGridView1.ColumnCount = 2;
                }
            }else
            {
                MessageBox.Show("Вы не выбрали, или выбрали неверный способ ввода данных!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void открытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (toolStripComboBox2.SelectedIndex == 1)
            {
                try
                {
                    DialogResult res = openFileDialog1.ShowDialog();

                    if (res == DialogResult.OK)
                    {
                        fileName = openFileDialog1.FileName;

                        Text = fileName;

                        OpenExcelFile(fileName);
                    }
                    else
                    {
                        throw new Exception("Файл не выбран!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Вы не выбрали способ ввода данных!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
           
        }

        private void OpenExcelFile(string path)
        {
            FileStream stream = File.Open(path, FileMode.Open, FileAccess.Read);

            IExcelDataReader reader = ExcelReaderFactory.CreateReader(stream);

            DataSet db = reader.AsDataSet(new ExcelDataSetConfiguration()
            {
                ConfigureDataTable = (x) => new ExcelDataTableConfiguration()
                {
                    UseHeaderRow = false
                }
            });

            tableCollection = db.Tables;

            toolStripComboBox1.Items.Clear();

            foreach(DataTable table in tableCollection)
            {
                toolStripComboBox1.Items.Add(table.TableName);
            }

            toolStripComboBox1.SelectedIndex = 0;
          
        }

        private void toolStripComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable table = tableCollection[Convert.ToString(toolStripComboBox1.SelectedItem)];

            dataGridView1.DataSource = table;
        }

        private void toolStripComboBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
