﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using ExcelDataReader;
using ZedGraph;

namespace Sortirovka
{
    public partial class Form1 : Form
    {

        private string fileName = string.Empty;

        private DataTableCollection tableCollection = null;

        public Form1()
        {
            InitializeComponent();
        }

        private void закрытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void очиститьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label2.Text = "";
            label3.Text = "";
            label4.Text = "";
            label5.Text = "";
            label6.Text = "";

            numericUpDown1.Value = 0;

            dataGridView2.Visible = false;
            dataGridView3.Visible = false;
            dataGridView4.Visible = false;
            dataGridView5.Visible = false;
            dataGridView6.Visible = false;

            try
            {
                dataGridView1.Rows.Clear();
                dataGridView1.Columns.Clear();
                dataGridView1.DataSource = null;

                dataGridView2.Rows.Clear();
                dataGridView2.Columns.Clear();
                dataGridView2.DataSource = null;

                dataGridView3.Rows.Clear();
                dataGridView3.Columns.Clear();
                dataGridView3.DataSource = null;

                dataGridView4.Rows.Clear();
                dataGridView4.Columns.Clear();
                dataGridView4.DataSource = null;

                dataGridView5.Rows.Clear();
                dataGridView5.Columns.Clear();
                dataGridView5.DataSource = null;

                dataGridView6.Rows.Clear();
                dataGridView6.Columns.Clear();
                dataGridView6.DataSource = null;
            }
            catch
            {
                dataGridView1.DataSource = null;

                dataGridView2.DataSource = null;

                dataGridView3.DataSource = null;

                dataGridView4.DataSource = null;

                dataGridView4.DataSource = null;

                dataGridView5.DataSource = null;

                dataGridView6.DataSource = null;
            }

        }

        private void отсортироватьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView2.Visible = false;
            dataGridView3.Visible = false;
            dataGridView4.Visible = false;
            dataGridView5.Visible = false;
            dataGridView6.Visible = false;

            try
            {
                dataGridView2.Rows.Clear();
                dataGridView2.Columns.Clear();
                dataGridView2.DataSource = null;

                dataGridView3.Rows.Clear();
                dataGridView3.Columns.Clear();
                dataGridView3.DataSource = null;

                dataGridView4.Rows.Clear();
                dataGridView4.Columns.Clear();
                dataGridView4.DataSource = null;

                dataGridView5.Rows.Clear();
                dataGridView5.Columns.Clear();
                dataGridView5.DataSource = null;

                dataGridView6.Rows.Clear();
                dataGridView6.Columns.Clear();
                dataGridView6.DataSource = null;
            }
            catch
            {
                dataGridView2.DataSource = null;

                dataGridView3.DataSource = null;

                dataGridView4.DataSource = null;

                dataGridView4.DataSource = null;

                dataGridView5.DataSource = null;

                dataGridView6.DataSource = null;
            }

            label2.Text = "";
            label3.Text = "";
            label4.Text = "";
            label5.Text = "";
            label6.Text = "";

            if (dataGridView1.Rows.Count == 0)
            {
                MessageBox.Show("Вы не ввели данные!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (checkBox1.Checked || checkBox2.Checked || checkBox3.Checked || checkBox4.Checked || checkBox5.Checked)
                {
                    double x;

                    int s = Convert.ToInt32(numericUpDown1.Value);

                    double[] massiv = new double[dataGridView1.Rows.Count];

                    for (int i = 0; i < dataGridView1.Rows.Count; i++)
                    {
                        massiv[i] = double.Parse(dataGridView1[0, i].Value.ToString());
                    }

                    if (checkBox1.Checked)
                    {
                        dataGridView2.Visible = true;

                        dataGridView2.RowCount = s;
                        dataGridView2.ColumnCount = 1;

                        System.Diagnostics.Stopwatch swatch = new System.Diagnostics.Stopwatch();
                        swatch.Start();
                        if (radioButton1.Checked)
                        {
                            BS(massiv);

                            for (int row = 0; row < dataGridView2.Rows.Count; row++)
                            {
                                for (int g = 0; g < massiv.Length; g++)
                                {
                                    dataGridView2[0, g].Value = massiv[g];
                                }
                            }
                        }
                        else
                        {
                            BS(massiv);
                            Array.Reverse(massiv);

                            for (int row = 0; row < dataGridView2.Rows.Count; row++)
                            {
                                for (int g = 0; g < massiv.Length; g++)
                                {
                                    dataGridView2[0, g].Value = massiv[g];
                                }
                            }
                        }
                        swatch.Stop();
                        label2.Text = Convert.ToString(swatch.Elapsed);

                    }

                    if (checkBox2.Checked)
                    {
                        dataGridView3.Visible = true;

                        dataGridView3.RowCount = s;
                        dataGridView3.ColumnCount = 1;

                        System.Diagnostics.Stopwatch swatch = new System.Diagnostics.Stopwatch();
                        swatch.Start();
                        if (radioButton1.Checked)
                        {
                            IS(massiv);

                            for (int row = 0; row < dataGridView3.Rows.Count; row++)
                            {
                                for (int g = 0; g < massiv.Length; g++)
                                {
                                    dataGridView3[0, g].Value = massiv[g];
                                }
                            }
                        }
                        else
                        {
                            IS(massiv);
                            Array.Reverse(massiv);

                            for (int row = 0; row < dataGridView3.Rows.Count; row++)
                            {
                                for (int g = 0; g < massiv.Length; g++)
                                {
                                    dataGridView3[0, g].Value = massiv[g];
                                }
                            }
                        }
                        swatch.Stop();
                        label3.Text = Convert.ToString(swatch.Elapsed);
                    }

                    if (checkBox3.Checked)
                    {
                        dataGridView4.Visible = true;

                        dataGridView4.RowCount = s;
                        dataGridView4.ColumnCount = 1;

                        System.Diagnostics.Stopwatch swatch = new System.Diagnostics.Stopwatch();
                        swatch.Start();
                        if (radioButton1.Checked)
                        {
                            SSAISN(massiv);

                            for (int row = 0; row < dataGridView4.Rows.Count; row++)
                            {
                                for (int g = 0; g < massiv.Length; g++)
                                {
                                    dataGridView4[0, g].Value = massiv[g];
                                }
                            }

                        }
                        else
                        {
                            SSAISN(massiv);
                            Array.Reverse(massiv);

                            for (int row = 0; row < dataGridView4.Rows.Count; row++)
                            {
                                for (int g = 0; g < massiv.Length; g++)
                                {
                                    dataGridView4[0, g].Value = massiv[g];
                                }
                            }
                        }
                        swatch.Stop();
                        label4.Text = Convert.ToString(swatch.Elapsed);
                    }

                    if (checkBox4.Checked)
                    {
                        dataGridView5.Visible = true;

                        dataGridView5.RowCount = s;
                        dataGridView5.ColumnCount = 1;

                        System.Diagnostics.Stopwatch swatch = new System.Diagnostics.Stopwatch();
                        swatch.Start();
                        if (radioButton1.Checked)
                        {
                            double minIndex = 0, maxIndex = massiv.Length - 1;
                            QSASIN(massiv, minIndex, maxIndex);

                            for (int row = 0; row < dataGridView5.Rows.Count; row++)
                            {
                                for (int g = 0; g < massiv.Length; g++)
                                {
                                    dataGridView5[0, g].Value = massiv[g];
                                }
                            }
                        }
                        else
                        {
                            double minIndex = 0, maxIndex = massiv.Length - 1;
                            QSASIN(massiv, minIndex, maxIndex);
                            Array.Reverse(massiv);

                            for (int row = 0; row < dataGridView5.Rows.Count; row++)
                            {
                                for (int g = 0; g < massiv.Length; g++)
                                {
                                    dataGridView5[0, g].Value = massiv[g];
                                }
                            }
                        }
                        swatch.Stop();
                        label5.Text = Convert.ToString(swatch.Elapsed);
                    }

                    if (checkBox5.Checked)
                    {
                        dataGridView6.Visible = true;

                        dataGridView6.RowCount = s;
                        dataGridView6.ColumnCount = 1;

                        System.Diagnostics.Stopwatch swatch = new System.Diagnostics.Stopwatch();
                        swatch.Start();
                        if (radioButton1.Checked)
                        {
                            BogoSort(ref massiv);
                            for (int row = 0; row < dataGridView6.Rows.Count; row++)
                            {
                                for (int g = 0; g < massiv.Length; g++)
                                {
                                    dataGridView6[0, g].Value = massiv[g];
                                }
                            }
                        }
                        else
                        {
                            BogoSort(ref massiv);
                            Array.Reverse(massiv);
                            for (int row = 0; row < dataGridView6.Rows.Count; row++)
                            {
                                for (int g = 0; g < massiv.Length; g++)
                                {
                                    dataGridView6[0, g].Value = massiv[g];
                                }
                            }
                        }
                        swatch.Stop();
                        label6.Text = Convert.ToString(swatch.Elapsed);
                    }
                }
                else
                {
                    MessageBox.Show("Вы не выбрали сортировку!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        
        static async void QSASIN(double[] massiv, double minIndex, double maxIndex) => await Task.Run(() => Qs(massiv, minIndex, maxIndex));
        
        static async void SSAISN(double[] massiv) => await Task.Run(() => SheikSort(massiv));
        
        static async void BS(double[] massiv) => await Task.Run(() => BubbleSort(massiv));
        
        static async void IS(double[] massiv) => await Task.Run(() => InsertSort(massiv));
        

        static void Swap3(double[] array, int i, int j)
        {
            double temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
        static void SheikSort(double[] massiv)
        {
            int left = 0,
                 right = massiv.Length - 1;
            while (left < right)
            {
                for (int i = left; i < right; i++)
                {
                    if (massiv[i] > massiv[i + 1])
                        Swap3(massiv, i, i + 1);
                }
                right--;
                for (int i = right; i > left; i--)
                {
                    if (massiv[i - 1] > massiv[i])
                        Swap3(massiv, i - 1, i);
                }
                left++;
            }
        }

        static void BubbleSort(double[] massiv)
        {
            double temp;
            for (int i = 0; i < massiv.Length; i++)
            {
                for (int j = i + 1; j < massiv.Length; j++)
                {
                    if (massiv[i] > massiv[j])
                    {
                        temp = massiv[i];
                        massiv[i] = massiv[j];
                        massiv[j] = temp;
                    }
                }
            }
        }

        static void InsertSort(double[] massiv)
        {
            for (int i = 1; i < massiv.Length; i++)
            {
                int cur = (int)massiv[i];
                int j = i;
                while (j > 0 && cur < massiv[j - 1])
                {
                    massiv[j] = massiv[j - 1];
                    j--;
                }
                massiv[j] = cur;
            }
        }
        
        static void Swap(ref double x, ref double y)
        {
            var t = x;
            x = y;
            y = t;
        }

        static double Partition(double[] massiv, double minIndex, double maxIndex)
        {
            var pivot = minIndex - 1;
            for (var i = minIndex; i < maxIndex; i++)
            {
                if (massiv[(int)i] < massiv[(int)maxIndex])
                {
                    pivot++;
                    Swap(ref massiv[(int)pivot], ref massiv[(int)i]);
                }
            }

            pivot++;
            Swap(ref massiv[(int)pivot], ref massiv[(int)maxIndex]);
            return pivot;
        }

        static double[] Qs(double[] massiv, double minIndex, double maxIndex)
        {
            if (minIndex >= maxIndex)
            {
                return massiv;
            }

            var pivotIndex = Partition(massiv, minIndex, maxIndex);
            Qs(massiv, minIndex, pivotIndex - 1);
            Qs(massiv, pivotIndex + 1, maxIndex);

            return massiv;
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(numericUpDown1.Text, "[^0-9]"))
            {
                MessageBox.Show("Please enter only numbers.");
                numericUpDown1.Text = numericUpDown1.Text.Remove(numericUpDown1.Text.Length - 1);
            }

        }

        private static bool IsSorted(ref double[] massiv)
        {
            int count = massiv.Length;

            while (--count >= 1)
                if (massiv[count] < massiv[count - 1]) return false;

            return true;
        }

        private static void Shuffle(ref double[] massiv)
        {
            double temp, rnd;
            Random rand = new Random();

            for (int i = 0; i < massiv.Length; ++i)
            {
                rnd = rand.Next(massiv.Length);
                temp = massiv[(int)i];
                massiv[i] = massiv[(int)rnd];
                massiv[(int)rnd] = temp;
            }
        }

        public static void BogoSort(ref double[] massiv)
        {
            while (!IsSorted(ref massiv))
                Shuffle(ref massiv);
        }

       
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                dataGridView1.Rows.Clear();
                dataGridView1.Columns.Clear();
                dataGridView1.DataSource = null;
            }
            catch
            {
                dataGridView1.DataSource = null;
            }

            dataGridView1.DataSource = null;


            if (numericUpDown1.Text == "0" || numericUpDown1.Text == "" || Convert.ToDouble(numericUpDown1.Text) < 0)
            {
                MessageBox.Show("Вы не ввели количество строк!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    int stroka;

                    stroka = Convert.ToInt32(numericUpDown1.Value);

                    dataGridView1.AllowUserToAddRows = false;

                    dataGridView1.RowCount = stroka;
                    dataGridView1.ColumnCount = 1;

                }
                catch 
                {
                    MessageBox.Show("Error", "Введено недопостимое количество точек!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                dataGridView1.Rows.Clear();
                dataGridView1.Columns.Clear();
                dataGridView1.DataSource = null;
            }
            catch
            {
                dataGridView1.DataSource = null;
            }

            dataGridView1.AllowUserToAddRows = false;

            if (numericUpDown1.Text == "0" || numericUpDown1.Text == "" || Convert.ToDouble(numericUpDown1.Text) < 0)
            {
                MessageBox.Show("Вы не ввели количество строк!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    int stroka;

                    stroka = Convert.ToInt32(numericUpDown1.Value);

                    dataGridView1.AllowUserToAddRows = false;

                    dataGridView1.RowCount = stroka;
                    dataGridView1.ColumnCount = 1;

                    Random rnd = new Random();
                    double[] mas1 = new double[stroka];

                    for (int i = 0; i < mas1.Length; i++)
                    {
                        mas1[i] = rnd.Next(1, 10000000);

                    }

                    for (int row = 0; row < dataGridView1.Rows.Count; row++)
                    {
                        for (int i = 0; i < mas1.Length; i++)
                        {
                            dataGridView1[0, i].Value = mas1[i];
                        }
                    }


                }
                catch 
                {
                    MessageBox.Show("Error", "Введено недопостимое количество точек!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }


        private void OpenExcelFile(string path)
        {
            FileStream stream = File.Open(path, FileMode.Open, FileAccess.Read);

            IExcelDataReader reader = ExcelReaderFactory.CreateReader(stream);

            DataSet db = reader.AsDataSet(new ExcelDataSetConfiguration()
            {
                ConfigureDataTable = (x) => new ExcelDataTableConfiguration()
                {
                    UseHeaderRow = false
                }
            });

            tableCollection = db.Tables;

            toolStripComboBox1.Items.Clear();

            foreach (DataTable table in tableCollection)
            {
                toolStripComboBox1.Items.Add(table.TableName);
            }

            toolStripComboBox1.SelectedIndex = 0;

        }

        private void toolStripComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable table = tableCollection[Convert.ToString(toolStripComboBox1.SelectedItem)];

            dataGridView1.DataSource = table;

        }

        private void открытьToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            try
            {
                dataGridView1.Rows.Clear();
                dataGridView1.Columns.Clear();
                dataGridView1.DataSource = null;
            }
            catch
            {
                dataGridView1.DataSource = null;
            }

            dataGridView1.AllowUserToAddRows = false;

            try
            {
                DialogResult res = openFileDialog1.ShowDialog();

                if (res == DialogResult.OK)
                {
                    fileName = openFileDialog1.FileName;

                    Text = fileName;

                    OpenExcelFile(fileName);
                }
                else
                {
                    throw new Exception("Файл не выбран!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }
    }
}
